

#include "msp430g2231.h"
#include "init.h"


void InitPort(void){
	  P1OUT = 0x00;                        			// Init ouput to null
	  P1DIR = BIT0;                        			// P1.0 output

}
