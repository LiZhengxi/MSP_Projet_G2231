//------------------------------------------------------------------------------
// init.h contains prototype of init functions.
//------------------------------------------------------------------------------
#ifndef INIT_HEADER
#define INIT_HEADER

#define TIME_TO_CHECK 400000


void InitPort(void);

#endif
