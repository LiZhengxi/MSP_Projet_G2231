/*
 *  Nom : SPI_Init.h
 *
 *  Date de cr��ation : 03.15.2018
 *
 *  Description : Bibliotheque de SPI
 *
 */

#ifndef SPI_INIT_H_
#define SPI_INIT_H_

void Init_SPI(void);
unsigned char RX_Data();

#endif /* SPI_INIT_H_ */
