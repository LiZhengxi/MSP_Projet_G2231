//******************************************************************************
//Description : finish to make the communication enter two microP, clik the button 2553
//P1.3 can make de LED1 in 2231 turn on or off and the servomoteur will turn to 0 deg and then 90
//and at the beginning the servomoteur will reset to 0 deg
//Version 1.2
//But : finish the part SPI
//******************************************************************************

#include "msp430g2231.h"
#include "Driver_Motor_IR.h"
#include "init.h"
void SPI_init();

int main(void)
{

  SPI_init();
  Motor_IR_Init();
  Motor_Start();                     //Make the servomoteur start
  TACCR1 = Motor_Set_Deg(0);          //Set de beginning deg
  __delay_cycles(80000);              //Waiting for some time to turn in the deg mecaniquement
  _BIS_SR(LPM0_bits + GIE);     // Enter LPM0 w/ interrupt
  while(1);
}

// USI interrupt service routine
#pragma vector=USI_VECTOR
__interrupt void universal_serial_interface(void)
{
  if (0x10 & USISRL)
    {P1OUT ^= 0x01;
    TACCR1 = Motor_Set_Deg(0);    //turn to 0��
    __delay_cycles(TIME_TO_CHECK);//Wait
    TACCR1 = Motor_Set_Deg(90);   //turn to 90��
    __delay_cycles(TIME_TO_CHECK);//Wait
    }

  else
  P1OUT &= ~0x01;
  USISRL = P1IN;
  USICNT = 8;                           // re-load counter
}

void SPI_init(void)
{
    P1DIR = 0x01;                         // P1.0 output, else input
      USICTL0 |= USIPE7 + USIPE6+ USIPE5 + USIOE; // Port, SPI slave
      USICTL1 |= USIIE;                     // Counter interrupt, flag remains set
      USICTL0 &= ~USISWRST;                 // USI released for operation
      USISRL = P1IN;                        // init-load data
      USICNT = 8;
}
